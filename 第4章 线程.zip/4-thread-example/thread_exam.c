#include <stdio.h>
#include <pthread.h>
#include "string.h"

#define time_sleep  5 //time of delay, u second
#define NNN  5

long m,n;

void *calculate_m();
void *calculate_n();

int main(int argN, char *arg[])
{
    pthread_t tid_m,tid_n;
    int i;

    pthread_create(&tid_m,NULL,calculate_m,NULL);
    pthread_create(&tid_n,NULL,calculate_n,NULL);

    for(i=1;i<=atoi(arg[1]);i++)
      {
         usleep(time_sleep);   //u second delay
         //pthread_yield();
         printf("Main thread, the middle result m+n = %ld\n",m+n);
      }
    pthread_join(tid_m,NULL);
    pthread_join(tid_n,NULL);
    
    printf("Main thread, the final result m+n = %ld\n\n",m+n);

}

void *calculate_m()
{
    int i;

    m = 0;
    for(i=1;i<=NNN;i++)
      {   m = m + i;
          //pthread_yield();
          usleep(time_sleep);
          printf("Thread m, 1+..+%d = %ld\n",i,m);
      }
    printf("Thread m, the final result = %ld\n\n",m);
    pthread_exit("calculate_m");
}

void *calculate_n()
{
    int i;
    
    n = 0;
    for(i=1;i<=NNN;i++)
      {   n = n + i;
          //pthread_yield();
          usleep(time_sleep);
          printf("Thread n, 1+..+%d = %ld\n",i,n);
     }
    printf("Thread n, the final result = %ld\n\n",n);
    pthread_exit("calculate_n");

}

