#include <stdio.h>

long m,n;

int main(void)
{
    int i;
    int MMM;

    printf("Input MMM = ");
    scanf("%d",&MMM);

    /*����1 -- MMM �����ۼӺ� == > m  */
    m = 0;
    for(i=1;i<=MMM;i++)
      {   m = m + i;
      }
    printf("Sum from 1 to %d = %d\n",MMM,m);

    /*����MMM -- MMM*2 �����ۼӺ� == > n  */
    n = 0;
    for(i=MMM+1;i<=MMM*2;i++)
      {   n = n + i;
      }
    printf("Sum from %d to %d = %d\n",MMM+1,2*MMM,n);

    printf("\nMain thread m+n = %ld\n\n",m+n);

}

